package com.example.projetdevmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page2);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) FloatingActionButton button = findViewById(R.id.buttonCancel);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button add = findViewById(R.id.ajout);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) EditText titre = findViewById(R.id.titre);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) EditText contenu = findViewById(R.id.contenu);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this, com.example.projetdevmobile.MainActivity.class);
                startActivity(intent);
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                com.example.projetdevmobile.BaseDeDonnee myDB = new com.example.projetdevmobile.BaseDeDonnee(MainActivity2.this);
                myDB.addarticle(titre.getText().toString().trim(), contenu.getText().toString().trim());
            }
        });
    }
}