package com.example.projetdevmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page3);
        TextView titre= findViewById(R.id.titre);
        TextView contenu= findViewById(R.id.contenu);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) FloatingActionButton button = findViewById(R.id.BoutonRetour);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(MainActivity3.this, com.example.projetdevmobile.MainActivity.class);
                startActivity(intent);
            }
        });
        Intent intent1=getIntent();
        titre.setText(intent1.getStringExtra("titre").substring(0,Math.min(intent1.getStringExtra("titre").length(),28)));
        contenu.setText(intent1.getStringExtra("contenu"));
    }
}