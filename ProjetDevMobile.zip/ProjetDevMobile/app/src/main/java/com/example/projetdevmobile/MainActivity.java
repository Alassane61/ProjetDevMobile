package com.example.projetdevmobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    com.example.projetdevmobile.MyDatabaseHelper mydb;
    ArrayList<String> titre,contenu,id;
    LinearLayout linearLayoutParent=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        linearLayoutParent = findViewById(R.id.linearLayout);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) FloatingActionButton button= findViewById(R.id.ajouter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(MainActivity.this, com.example.projetdevmobile.MainActivity2.class);
                startActivity(intent);
            }
        });

        mydb= new com.example.projetdevmobile.MyDatabaseHelper(MainActivity.this);
        titre= new ArrayList<>();
        contenu= new ArrayList<>();
        id= new ArrayList<>();
        DisplayData();

    }

    void DisplayData (){
        Cursor cursor = mydb.readAllData();

        if(cursor.getCount()==0){
            Toast.makeText(this, "Il n'y a pas d'articles.", Toast.LENGTH_SHORT).show();
        }else{
            int i =0;
            while (cursor.moveToNext()){
                id.add(cursor.getString(0));
                titre.add(cursor.getString(1));
                contenu.add(cursor.getString(2));

                LinearLayout linearLayout= new LinearLayout(this);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(600, LinearLayout.LayoutParams.WRAP_CONTENT);
                params.topMargin = 10;
                params.leftMargin = 30;
                linearLayout.setLayoutParams(params);
                linearLayout.setOrientation(LinearLayout.VERTICAL);
                linearLayout.setPadding(10, 10, 10, 20);

                linearLayout.setElevation(20);
                linearLayout.setTranslationY(16);
                linearLayout.setGravity(Gravity.CENTER_VERTICAL);
                linearLayout.setBackground(ContextCompat.getDrawable(this, R.drawable.fond1));
                TextView articleTitle = new TextView(this);
                LinearLayout.LayoutParams paramss = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                paramss.leftMargin = 35;
                articleTitle.setLayoutParams(paramss);
                articleTitle.setText(titre.get(i));
                articleTitle.setTextColor(Color.BLACK);
                articleTitle.setTypeface(null, Typeface.BOLD);
                articleTitle.setTextSize(24);
                TextView articleContent = new TextView(this);
                LinearLayout.LayoutParams paramsss = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                paramsss.leftMargin = 35;
                articleContent.setLayoutParams(paramsss);
                String contenuPartiel = contenu.get(i).substring(0, Math.min(contenu.get(i).length(), 134));
                articleContent.setText(contenuPartiel);
                linearLayout.addView(articleTitle);
                linearLayout.addView(articleContent);

                linearLayoutParent.addView(linearLayout);

                int finalI = i;
                linearLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, com.example.projetdevmobile.MainActivity3.class);
                        intent.putExtra("titre",titre.get(finalI).toString());
                        intent.putExtra("contenu",contenu.get(finalI).toString());
                        startActivity(intent);

                    }
                });
                i++;

            }
        }
    }
}